/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

/**
 *
 * @author DudaE
 */
public class Calculadora {
    
    private Double resultado = 0.0;
    
    
    public void setSoma(Double primeiroNumero, Double segundoNumero){
        this.resultado = primeiroNumero + segundoNumero;
    }
       
    public void setSubtracao(Double primeiroNumero, Double segundoNumero){
         this.resultado = primeiroNumero - segundoNumero;
    }
    
    public void setMultiplicacao(Double primeiroNumero, Double segundoNumero){
         this.resultado = primeiroNumero * segundoNumero;
    }
    
    public void setDivisao(Double primeiroNumero, Double segundoNumero){
         this.resultado = primeiroNumero / segundoNumero;
    }
    
    public Double getResultado(){
        return resultado;
    }
}

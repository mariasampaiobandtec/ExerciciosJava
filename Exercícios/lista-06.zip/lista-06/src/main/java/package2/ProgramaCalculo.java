/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class ProgramaCalculo {

    public static void main(String[] args) {

        Calculadora numero = new Calculadora();
        Scanner leitor = new Scanner(System.in);

        System.out.println("Iniciando calculadora\n");

        System.out.println("Digite o primeiro número:");
        Double primeiroNumero = leitor.nextDouble();

        System.out.println("\nDigite o segundo número:");
        Double segundoNumero = leitor.nextDouble();

        System.out.println("\n-----------------------------------------------------\n");

        numero.setSoma(primeiroNumero, segundoNumero);
        System.out.println("Resultado soma = " + numero.getResultado());

        numero.setSubtracao(primeiroNumero, segundoNumero);
        System.out.println("\nResultado Subtração = " + numero.getResultado());

        numero.setMultiplicacao(primeiroNumero, segundoNumero);
        System.out.println("\nResultado Multiplicação = " + numero.getResultado());

        numero.setDivisao(primeiroNumero, segundoNumero);
        System.out.println("\nResultado Divisão = " + numero.getResultado());
        

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class ProgramaCampeonato {
    
    public static void main(String[] args) {
        
        Clube palmeiras = new Clube();
        Clube saoPaulo = new Clube();
        
        
        System.out.println("Começa o Jogo!!\n");
        
        palmeiras.setVencer();
        saoPaulo.setPerder();
        
        System.out.println("Palmeiras ganhou nessa rodada"
        +"\nSão Paulo perdeu nessa rodada\n");
        
        System.out.println(String.format("Palmeiras pontos: %d", palmeiras.getPontos()));
        System.out.println(String.format("São Paulo pontos: %d", saoPaulo.getPontos()));
        
        System.out.println("\n---------------------------------------------------------\n");
        
        saoPaulo.setVencer();
        palmeiras.setPerder();
        
        System.out.println("São Paulo ganhou nessa rodada"
        +"\nPalmeiras perdeu nessa rodada\n");
        
        System.out.println(String.format("Palmeiras pontos: %d", palmeiras.getPontos()));
        System.out.println(String.format("São Paulo pontos: %d", saoPaulo.getPontos()));
        
        System.out.println("\n---------------------------------------------------------\n");
        
        palmeiras.setVencer();
        saoPaulo.setPerder();
        
        System.out.println("Palmeiras ganhou nessa rodada"
        +"\nSão Paulo perdeu nessa rodada\n");
        
        System.out.println(String.format("Palmeiras pontos: %d", palmeiras.getPontos()));
        System.out.println(String.format("São Paulo pontos: %d", saoPaulo.getPontos()));
        
        System.out.println("\n---------------------------------------------------------\n");
        
        System.out.println("Final de temporada:");
        
        System.out.println(String.format("Palmeiras: %d vitórias || %d empates || %d derrotas"
        +"\nTotal de pontos: %d", palmeiras.getVitoria(), palmeiras.getEmpate(), palmeiras.getDerrota(), palmeiras.getPontos()));
        
        System.out.println(String.format("\nSão Paulo: %d vitórias || %d empates || %d derrotas"
        +"\nTotal de pontos: %d", saoPaulo.getVitoria(), saoPaulo.getEmpate(), saoPaulo.getDerrota(), saoPaulo.getPontos()));
      
    }
}

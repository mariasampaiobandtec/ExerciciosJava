/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class Clube {

    private Integer vitoria = 0;
    private Integer derrota = 0;
    private Integer empate = 0;
    private Integer pontos = 0;

    public void setVencer() {
        vitoria += 1;
        pontos += 3;
    }

    public void setPerder() {
        derrota += 1;
    }

    public void setNeutro() {
        empate += 1;
        pontos += 1;
    }

    public Integer getVitoria() {
        return vitoria;
    }

    public Integer getDerrota() {
        return derrota;
    }

    public Integer getEmpate() {
        return empate;
    }

    public Integer getPontos() {
        return pontos;
    }

}

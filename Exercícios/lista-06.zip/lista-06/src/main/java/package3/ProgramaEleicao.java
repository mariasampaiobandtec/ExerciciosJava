/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package3;

/**
 *
 * @author DudaE
 */
public class ProgramaEleicao {

    public static void main(String[] args) {

        UrnaEletronica candidato1 = new UrnaEletronica();
        UrnaEletronica candidato2 = new UrnaEletronica();

        System.out.println("Votação para representante de sala");

        candidato1.setVotos();
        candidato2.setVotos();

        System.out.println(String.format("Candidato 1 recebeu 1 voto, totalizando %d", candidato1.getVotos()));
        System.out.println(String.format("\nCandidato 2 recebeu 1 voto, totalizando %d", candidato2.getVotos()));
        System.out.println("Total de votos: " + (candidato1.getVotos() + candidato2.getVotos()));

        System.out.println("\n--------------------------------------------------------------\n");

        candidato1.setVotos();
        candidato2.setVotos();

        System.out.println(String.format("Candidato 1 recebeu 1 voto, totalizando %d", candidato1.getVotos()));
        System.out.println(String.format("\nCandidato 2 recebeu 1 voto, totalizando %d", candidato2.getVotos()));
        System.out.println("Total de votos: " + (candidato1.getVotos() + candidato2.getVotos()));

        System.out.println("\n--------------------------------------------------------------\n");

        candidato1.setVotos();
        candidato1.setVotos();
        candidato2.setVotos();

        System.out.println(String.format("Candidato 1 recebeu 2 votos, totalizando %d", candidato1.getVotos()));
        System.out.println(String.format("\nCandidato 2 recebeu 1 voto, totalizando %d", candidato2.getVotos()));
        System.out.println("Total de votos: " + (candidato1.getVotos() + candidato2.getVotos()));

        System.out.println("\n--------------------------------------------------------------\n");

        System.out.println("Eleição encerrada!\n");

        System.out.println("Total de votos: " + (candidato1.getVotos() + candidato2.getVotos()));

        if (candidato1.getVotos() > candidato2.getVotos()) {
            System.out.println("Diego venceu!");
        } else if (candidato2.getVotos() > candidato1.getVotos()) {
            System.out.println("Caio venceu!");
        } else {
            System.out.println("Empate!");
        }

    }

}

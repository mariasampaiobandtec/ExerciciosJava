/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista.resolucao;

/**
 *
 * @author DudaE
 */
public class Empregado {

    // Atributos
    private String nome;
    private String cargo;
    private Double salario;

    // Construtores
    public Empregado(String nome, String cargo, Double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;

    }

    public Empregado(Double reajuste) {
        this.salario = salario;

    }

    //Métodos
    public void reajustarSalario(Double reajuste) {
        salario += salario * reajuste;
        System.out.println(String.format("\nSalário Reajustado: %.2f", salario));

    }

    public void exibeDados() {
        System.out.println("--------------------------------------------------");
        System.out.println("\nDados do empregado:");
        System.out.println(String.format("\nNome: %s", nome));
        System.out.println(String.format("Cargo: %s", cargo));
        System.out.println(String.format("Salário Inicial: %.2f", salario));

    }

    // Getter e Setter
    public String getNome() {
        return this.nome;
    }

    public String getCargo() {
        return this.cargo;
    }

    public Double getSalario() {
        return this.salario;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

}

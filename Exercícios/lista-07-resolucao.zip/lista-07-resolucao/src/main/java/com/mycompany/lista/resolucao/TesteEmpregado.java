/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista.resolucao;

/**
 *
 * @author DudaE
 */
public class TesteEmpregado {

    public static void main(String[] args) {

        Empregado e1 = new Empregado("João", "Analista de Sistema", 5400.00);
        e1.exibeDados();
        e1.reajustarSalario(0.15);

        Empregado e2 = new Empregado("Maria", "Desenvolvedora", 6000.00);
        e2.exibeDados();
        e2.reajustarSalario(0.1);

    }
}

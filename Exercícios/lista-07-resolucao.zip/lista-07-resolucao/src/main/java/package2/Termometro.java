/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

/**
 *
 * @author DudaE
 */
public class Termometro {

    // Atributos
    private Double temperaturaAtual;
    private Double temperaturaMax;
    private Double temperaturaMin;

    // Construtores
    public Termometro(Double temperaturaAtual, Double temperaturaMax, Double temperaturaMin) {
        this.temperaturaAtual = temperaturaAtual;
        this.temperaturaMax = temperaturaMax;
        this.temperaturaMin = temperaturaMin;
    }

    // Métodos 
    public void aumentaTemperatura() {

        if (temperaturaAtual > temperaturaMax) {
            temperaturaMax = temperaturaAtual;
        }

        System.out.println("\nAtualizando...");
        System.out.println(String.format("Temperatura Máxima: %.2f°", temperaturaMax));
    }

    public void diminuiTemperatura() {

        if (temperaturaAtual < temperaturaMin) {
            temperaturaMin = temperaturaAtual;
        }

        System.out.println("\nAtualizando...");
        System.out.println(String.format("Temperatura Mínima: %.2f°", temperaturaMin));
    }

    public void exibeFahreinheit() {
        System.out.println(String.format("\nTemperatura em Fahreinheit: %.2f°f", (temperaturaAtual * 1.8) + 32));
    }

    public void exibirDados() {
        System.out.println("--------------------------------------------------");
        System.out.println("\nExibindo dados...");
        System.out.println(String.format("\nTemperatura Atual: %.2f°", temperaturaAtual));
        System.out.println(String.format("Temperatura Maxima: %.2f°", temperaturaMax));
        System.out.println(String.format("Temperatura Mínima: %.2f°", temperaturaMin));

    }

    // Getter e Setter
    public Double getTemperaturaAtual() {
        return this.temperaturaAtual;
    }

    public Double getTemperaturaMax() {
        return this.temperaturaMax;
    }

    public Double getTemperaturaMin() {
        return this.temperaturaMin;
    }

    public void setTemperaturaAtual(Double temperaturaAtual) {
        this.temperaturaAtual = temperaturaAtual;
    }

    public void setTemperaturaMax(Double temperaturaMax) {
        this.temperaturaMax = temperaturaMax;
    }

    public void setTemperaturaMin(Double temperaturaMin) {
        this.temperaturaMin = temperaturaMin;
    }

}

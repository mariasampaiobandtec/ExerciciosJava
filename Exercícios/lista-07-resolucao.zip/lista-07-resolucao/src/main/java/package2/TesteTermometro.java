/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

/**
 *
 * @author DudaE
 */
public class TesteTermometro {

    public static void main(String[] args) {

        Termometro dados = new Termometro(35.0, 31.0, 28.0);

        dados.exibirDados();
        dados.aumentaTemperatura();
        dados.diminuiTemperatura();
        dados.exibeFahreinheit();

    }
}

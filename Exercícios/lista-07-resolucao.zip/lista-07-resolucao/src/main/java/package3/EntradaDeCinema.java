/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package3;

/**
 *
 * @author DudaE
 */
public class EntradaDeCinema {

    // Atributos
    private Integer hora;
    private Integer nSala;
    private Double vlrIngresso;
    private String nomeFilme;

    private Double vlrDesconto;

    // Construtores
    public EntradaDeCinema(Integer hora, Integer nSala, Double vlrIngresso, String nomeFilme) {
        this.hora = hora;
        this.nSala = nSala;
        this.vlrIngresso = vlrIngresso;
        this.nomeFilme = nomeFilme;
    }

    // Métodos
    public void calculaDesconto(Integer idade, Boolean estudante) {

        if (idade < 12) {
            vlrDesconto = vlrIngresso * 0.5;
            vlrIngresso = vlrIngresso - vlrDesconto;
            System.out.println(String.format("Ingresso com Desconto: %.2f", vlrIngresso));

        } else if (idade > 12 && idade <= 15 && estudante) {
            vlrDesconto = vlrIngresso * 0.4;
            vlrIngresso = vlrIngresso - vlrDesconto;
            System.out.println(String.format("Ingresso com Desconto: %.2f", vlrIngresso));

        } else if (idade > 16 && idade <= 20 && estudante) {
            vlrDesconto = vlrIngresso * 0.3;
            vlrIngresso = vlrIngresso - vlrDesconto;
            System.out.println(String.format("Ingresso com Desconto: %.2f", vlrIngresso));

        } else if (idade > 20 && estudante) {
            vlrDesconto = vlrIngresso * 0.2;
            vlrIngresso = vlrIngresso - vlrDesconto;
            System.out.println(String.format("Ingresso com Desconto: %.2f", vlrIngresso));

        } else {
            System.out.println(String.format("Total: %.2f", vlrIngresso));
        }
    }

    public void calculaDescontoHorario() {
        if (hora < 16) {
            vlrDesconto = vlrIngresso * 0.1;
            vlrIngresso = vlrIngresso - vlrDesconto;
            System.out.println("\nDesconto fora das 16h\n");
            System.out.println(String.format("Ingresso com Desconto: %.2f", vlrIngresso));
        }
    }

    public void exbirEntrada() {

        System.out.println("-------------------------------------------------");
        System.out.println("Entrada");
        System.out.println(String.format("\nHora: %dh", hora));
        System.out.println(String.format("Sala: %d", nSala));
        System.out.println(String.format("Ingresso: %.2f", vlrIngresso));
        System.out.println(String.format("Filme: %s", nomeFilme));

    }

    // Getter e Setter
    public Integer getHora() {
        return this.hora;
    }

    public Integer getNsala() {
        return this.nSala;
    }

    public Double getVlringresso() {
        return this.vlrIngresso;
    }

    public String getNomefilme() {
        return this.nomeFilme;
    }

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public void setNsala(Integer nSala) {
        this.nSala = nSala;
    }

    public void setVlringresso(Double vlrIngresso) {
        this.vlrIngresso = vlrIngresso;
    }

    public void setNomefilme(String Nomefilme) {
        this.nomeFilme = nomeFilme;
    }

}

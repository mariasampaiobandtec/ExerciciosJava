/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package3;

/**
 *
 * @author DudaE
 */
public class TesteCinema {
    
    public static void main(String[] args) {
        
        EntradaDeCinema cliente1 = new EntradaDeCinema(10, 01, 30.00, "Divertida Mente");
        
        //Cliente menor de 12 anos e com filme antes das 16h
        cliente1.exbirEntrada();
        cliente1.calculaDesconto(11, true);
        cliente1.calculaDescontoHorario();
        
        //Cliente com mais de 12 anos e estudante
        EntradaDeCinema cliente2 = new EntradaDeCinema(16, 11, 35.00, "Vingadores Ultimato");
        
        cliente2.exbirEntrada();
        cliente2.calculaDesconto(13, true);
        cliente2.calculaDescontoHorario();
        
        //Cliente com mais de 18 anos porém não é estudante e filme antes das 16h
        EntradaDeCinema cliente3 = new EntradaDeCinema(11, 10, 27.00, "Mulher Maravilha 2");
        
        cliente3.exbirEntrada();
        cliente3.calculaDesconto(18, false);
        cliente3.calculaDescontoHorario();
        
        //Cliente com mais de 20 anos e estudante
        EntradaDeCinema cliente4 = new EntradaDeCinema(18, 07, 31.00, "Parasita");
        
        cliente4.exbirEntrada();
        cliente4.calculaDesconto(21, true);
        cliente4.calculaDescontoHorario();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class CalculadoraPizza {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
        Scanner leitorS = new Scanner (System.in);
        
        System.out.println("Informe o valor da pizza:");
        Double valorPizza = leitor.nextDouble();
        
        System.out.println("Qual é o sabor da pizza?");
        String saborPizza = leitorS.nextLine();
        
        System.out.println("Quantas pessoas irão 'rachar' a conta?");
        Integer numeroPessoas = leitor.nextInt();
        
        System.out.println("Qual é o valor máximo que as pessoas aceitam 'rachar'?");
        Double valorMaximo = leitor.nextDouble();
        
        
        if ((valorPizza / numeroPessoas) <= valorMaximo) {
            System.out.println(String.format("A pizza de %s será dividida entre %d pessoas. R$VALOR para cada: %.2f", saborPizza, numeroPessoas, (valorPizza / numeroPessoas)));
        } else {
            System.out.println(String.format("Deu ruim no racha. A pizza deveria custar no máximo %.2f reais para cada.", (numeroPessoas * valorMaximo)));
        }
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Boletim {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Informe a primeira nota:");
        Double notaTotal = leitor.nextDouble();

        System.out.println("Informe a segunda nota:");
        notaTotal += leitor.nextDouble();

        System.out.println("Informe a terceira nota:");
        notaTotal += leitor.nextDouble();

        Double media = notaTotal / 3;

        System.out.println(String.format("\nSua média é: %.2f \n", media));

        if (media >= 5 && media < 7) {
            System.out.println("Têm direito de fazer uma prova de recuperação");
        } else if (media >= 7) {
            System.out.println("Passou direto");
        } else {
            System.out.println("Reprovado direto");
        }

    }
}

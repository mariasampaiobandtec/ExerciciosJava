/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class IndiceMassaCorporal {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Selecione o sexo:");
        System.out.println("1 - Feminino \t 2 - Masculino");
        Integer escolha = leitor.nextInt();

        System.out.println("Informe sua altura:");
        Double altura = leitor.nextDouble();

        System.out.println("Informe seu peso:");
        Double peso = leitor.nextDouble();

        peso = peso / (altura * altura);
        String avaliacao;

        switch (escolha) {
            case 1:
                if (peso < 19.1) {
                    avaliacao = "Abaixo do peso";
                } else if (peso >= 19.1 && peso < 25.8) {
                    avaliacao = "No peso normal";
                } else if (peso >= 25.8 && peso < 27.3) {
                    avaliacao = "Marginalmente acima do peso";
                } else if (peso >= 27.3 && peso < 32.3) {
                    avaliacao = "Acima do peso ideal";
                } else {
                    avaliacao = "Obeso";
                }
                break;

            case 2:
                if (peso < 20.7) {
                    avaliacao = "Abaixo do peso";
                } else if (peso >= 20.7 && peso < 26.4) {
                    avaliacao = "No peso normal";
                } else if (peso >= 26.4 && peso < 27.8) {
                    avaliacao = "Marginalmente acima do peso";
                } else if (peso >= 27.8 && peso < 31.1) {
                    avaliacao = "Acima do peso ideal";
                } else {
                    avaliacao = "Obeso";
                }
                break;
            default:
                avaliacao = "Escolha inválida, reinicie o programa.";
                break;
        }

        System.out.println(avaliacao);

    }

}

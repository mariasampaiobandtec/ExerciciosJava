/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Desconto {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Informe o valor do produto escolhido:");
        Double vlrProduto = leitor.nextDouble();

        System.out.println("Informe o código de desconto:");
        System.out.println("\tCódigo\t|\tDesconto\n"
                + "\t1\t|\t5%\n"
                + "\t2\t|\t10%\n"
                + "\t3\t|\t20%\n"
                + "\t4\t|\t50%\n");

        Integer codDesconto = leitor.nextInt();
        Double valorDesconto = 0.0;

        switch (codDesconto) {
            case 1:
                valorDesconto = (vlrProduto - (vlrProduto * 0.05));
                break;
            case 2:
                valorDesconto = (vlrProduto - (vlrProduto * 0.1));
                break;
            case 3:
                valorDesconto = (vlrProduto - (vlrProduto * 0.2));
                break;
            case 4:
                valorDesconto = (vlrProduto - (vlrProduto * 0.5));
                break;
            default:
                System.out.println("Código inválido.");
                break;
        }
        
        System.out.println(String.format("Valor do produto: R$%.2f\tValor com desconto: R$%.2f", vlrProduto , valorDesconto));

    }

}

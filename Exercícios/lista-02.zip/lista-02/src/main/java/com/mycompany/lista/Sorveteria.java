/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Sorveteria {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
        
        System.out.println("Selecione o sabor:");
        System.out.println("1 - Casquinha\t| 2 - Sundae\t| 3 - Milkshake");
        Integer opcao = leitor.nextInt();
        
        switch (opcao) {
        case 1:
        System.out.println("Casquinha custa R$2,00 reais");
        break;
        
        case 2:
        System.out.println("Sundae custa R$5,00 reais");
        break;
        
        case 3:
        System.out.println("Milkshake custa R$7,00 reais");
        break;
        default:
        System.out.println("Opção inválida");
        break;
    }
    }
    
}

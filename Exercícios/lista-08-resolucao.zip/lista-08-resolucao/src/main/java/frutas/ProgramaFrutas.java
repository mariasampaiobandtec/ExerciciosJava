package frutas;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class ProgramaFrutas {

    public static void main(String[] args) {

        List<String> listaFrutas = Arrays.asList("morango", "maçã", "laranja");

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o nome de uma fruta:");
        String fruta = leitor.nextLine();

        if (listaFrutas.contains(fruta.toLowerCase())) {
            System.out.println(String.format("A fruta %s contêm na lista.", fruta));
        } else {
            System.out.println(String.format("A fruta %s não contêm na lista.", fruta));
        }
    }

}

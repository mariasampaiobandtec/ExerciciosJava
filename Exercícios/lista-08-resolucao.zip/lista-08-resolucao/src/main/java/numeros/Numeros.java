package numeros;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Numeros {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        List<Integer> listaNumeros = new ArrayList<>();

        Integer numeros = 1;

        // Solicitando números
        do {

            System.out.println("Digite qualquer número. Digite 0 quando cansar: ");
            numeros = leitor.nextInt();

            if (numeros != 0) {
                listaNumeros.add(numeros);
            }

        } while (numeros != 0);

        //Exibindo números pares
        System.out.println("\nNúmeros Pares:");
        for (Integer numero : listaNumeros) {

            if (numero % 2 == 0) {
                System.out.println(numero);
            }

        }

        //Exibindo números ímpares
        System.out.println("\nNúmeros ímpares:");
        for (Integer numero : listaNumeros) {

            if (numero % 2 != 0) {
                System.out.println(numero);
            }
        }

        //Exibindo a soma dos números da lista
        Integer soma = 0;
        for (Integer numero : listaNumeros) {
            soma += numero;

        }

        System.out.println(String.format("\nA soma dos números da lista é %d", soma));

        //Exibindo o maior número da lista
        Integer maior = Integer.MIN_VALUE;

        for (Integer numero : listaNumeros) {
            if (numero > maior) {
                maior = numero;
            }
        }

        System.out.println(String.format("\nMaior número da lista: %d", maior));

        //Exibindo o menor número da lista
        Integer menor = Integer.MAX_VALUE;

        for (Integer numero : listaNumeros) {
            if (numero < menor) {
                menor = numero;
            }
        }

        System.out.println(String.format("\nMenor número da lista: %d", menor));
    }
}

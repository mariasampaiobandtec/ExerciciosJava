/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aluno;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DudaE
 */
public class Aluno {

    // Atributos
    private Integer ra;
    private String nome;
    private List<Disciplina> listaDisciplina;

    // Construtores
    public Aluno(Integer ra, String nome) {
        this.ra = ra;
        this.nome = nome;
        this.listaDisciplina = new ArrayList<>();
    }

    // Métodos 
    public void adiciona(String nome, Double notaContinuada, Double notaSemestral, Integer quantFalta) {

        Disciplina disciplinas = new Disciplina(nome, notaContinuada, notaSemestral, quantFalta);
        listaDisciplina.add(disciplinas);

    }

    public void exibirBoletim() {

        System.out.println(String.format("Nome do aluno(a): %s", this.nome));
        System.out.println(String.format("RA: %d", this.ra));

        for (Disciplina boletim : listaDisciplina) {
            System.out.println(String.format("\nDisciplina: %s", boletim.getNome()));
            System.out.println(String.format("Nota continuada: %.2f", boletim.getNotaContinuada()));
            System.out.println(String.format("Nota Semestral: %.2f", boletim.getNotaSemestral()));
            System.out.println(String.format("Faltas: %d", boletim.getQuantFalta()));
            System.out.println(String.format("Média: %.2f", boletim.getMedia()));
            System.out.println(String.format("Situação: %s", boletim.getAprovado() ? "\nAprovado!" : "Reprovado!\n"));

        }
    }

    //Getters
    public Integer getRa() {
        return ra;
    }

    public String getNome() {
        return nome;
    }

    public List<Disciplina> getListaDisciplina() {
        return listaDisciplina;
    }

    @Override
    public String toString() {
        return "Aluno{" + "ra=" + ra + ", nome=" + nome + ", listaDisciplina=" + listaDisciplina + '}';
    }

}

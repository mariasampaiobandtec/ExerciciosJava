/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aluno;

/**
 *
 * @author DudaE
 */
public class Disciplina {

    // Atributos
    private String nome;
    private Double notaContinuada;
    private Double notaSemestral;
    private Integer quantFalta;
    private Boolean aprovado;
    private Double media;

    // Construtores
    public Disciplina(String nome, Double notaContinuada, Double notaSemestral, Integer quantFalta) {
        this.nome = nome;
        this.notaContinuada = notaContinuada;
        this.notaSemestral = notaSemestral;
        this.quantFalta = quantFalta;
        this.media = calculaMedia();
        this.aprovado = isAprovado();
        
    }

    // Métodos
    public Double calculaMedia() {
        return (notaContinuada * 0.4) + (notaSemestral * 0.6);
    }

    //is é uma boa prática para métodos com Boolean
    public Boolean isAprovado() {
        return quantFalta <= 15 && media >= 6;
    }

    // Getter e Setter
    public String getNome() {
        return nome;
    }

    public Double getNotaContinuada() {
        return notaContinuada;
    }

    public Double getNotaSemestral() {
        return notaSemestral;
    }

    public Integer getQuantFalta() {
        return quantFalta;
    }

    public Boolean getAprovado() {
        return aprovado;
    }

    public Double getMedia() {
        return media;
    }
    
    

    //toString
    @Override
    public String toString() {
        return "Disciplina{" + "nome=" + nome + ", notaContinuada=" + notaContinuada + ", notaSemestral=" + notaSemestral + ", quantFalta=" + quantFalta + ", aprovado=" + aprovado + ", media=" + media + '}';
    }

}

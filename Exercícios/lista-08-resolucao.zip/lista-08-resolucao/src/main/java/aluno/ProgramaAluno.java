/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aluno;

/**
 *
 * @author DudaE
 */
public class ProgramaAluno {
    
    public static void main(String[] args) {
       Aluno aluno1 = new Aluno(1010, "Maria");
       
       aluno1.adiciona("Linguagem de Programação", 8.0, 9.5, 4);
       aluno1.adiciona("Sistemas Operacionais", 9.0, 10.0, 0);

       aluno1.exibirBoletim();
    }
}

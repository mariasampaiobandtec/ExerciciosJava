/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Random;

/**
 *
 * @author DudaE
 */
public class Dadinho {

    Integer dado1;
    Integer dado2;
    String mensagem;

    Integer vitoriaDado1 = 0;
    Integer vitoriaDado2 = 0;
    String mensagemVitoria;

    Random gerar = new Random();

    public void sortearDados() {
        dado1 = gerar.nextInt(7);
        dado2 = gerar.nextInt(7);
    }

    public void resultado() {
        if (dado1 > dado2) {
            mensagem = "O Dadinho 1 venceu essa rodada";
            vitoriaDado1++;

        } else if (dado1 < dado2) {
            mensagem = "O Dadinho 2 venceu essa rodada";
            vitoriaDado2++;
        } else {
            mensagem = "Vish, deu empate.";
        }
    }

    public void resultadoVitorias() {
        mensagemVitoria = "Vitórias do Dadinho 1: " + vitoriaDado1 + " || Vitórias do Dadinho 2: " + vitoriaDado2;
    }
}

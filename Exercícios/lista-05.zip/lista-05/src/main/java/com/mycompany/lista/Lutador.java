/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class Lutador {

    Integer vida1 = 100;
    Integer vida2 = 100;
    String mensagem = "";

    public void apanharLutador1() {

        if (vida1 == 0 || vida2 == 0) {
        } else {
            if (vida1 < 10) {
                vida1 = 0;
            } else {
                vida1 -= 10;
            }
        }
    }

    public void apanharLutador2() {
        if (vida2 == 0 || vida1 == 0) {
        } else {
            if (vida2 < 10) {
                vida2 = 0;
            } else {
                vida2 -= 10;
            }
        }
    }

    public void concentrarForca1() {
        if (vida1 == 0 || vida2 == 0) {
        } else {
            vida1 += 2;
        }
    }

    public void concentrarForca2() {
        if (vida2 == 0 || vida1 == 0) {
        } else {
            vida2 += 2;
        }
    }

    public void mensagem1() {
        if (vida1 == 0) {
            mensagem = "O lutador 2 venceu!";
        }
    }

    public void mensagem2() {
        if (vida2 == 0) {
            mensagem = "O lutador 1 venceu!";
        }
    }
}

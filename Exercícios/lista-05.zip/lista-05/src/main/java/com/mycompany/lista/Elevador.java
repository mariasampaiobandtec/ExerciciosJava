/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class Elevador {

    Integer pessoasTotal = 0;
    Integer pesoTotal = 0;

    public void entraHomem() {
        pessoasTotal += 1;
        pesoTotal += 90;
    }

    public void entraMulher() {
        pessoasTotal += 1;
        pesoTotal += 65;
    }

    public void entraCrianca() {
        pessoasTotal += 1;
        pesoTotal += 40;
    }

}

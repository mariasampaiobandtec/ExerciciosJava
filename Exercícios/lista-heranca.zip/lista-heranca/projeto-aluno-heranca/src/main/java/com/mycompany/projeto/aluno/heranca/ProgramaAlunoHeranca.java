package com.mycompany.projeto.aluno.heranca;

/**
 *
 * @author DudaE
 */
public class ProgramaAlunoHeranca {
    
    public static void main(String[] args) {
        
        //Criando objeto da classe Aluno
        Aluno aluno1 = new Aluno(1192022,"Maria", 8.0, 7.0);
        
        System.out.println(String.format("\nO(a) aluno(a) %s tem média %.2f.", aluno1.nome, aluno1.calculaMedia()));
        
        //Mostrando o toString da classe Aluno
        System.out.println(aluno1);
        
        Aluno aluno2 = new Aluno(1192027, "Eli", 7.0, 8.5);
        
        System.out.println(String.format("\nO(a) aluno(a) %s tem média %.2f.", aluno2.nome, aluno2.calculaMedia()));
        
        System.out.println(aluno2);
        
        //Criando objeto da classe AlunoPos
        AlunoPos alunoP1 = new AlunoPos(1192017, "Sampaio", 6.0, 7.0, 8.0);
        
        System.out.println(String.format("\nO(a) aluno(a) %s tem média %.2f", alunoP1.nome, alunoP1.calculaMedia()));
        
        //Mostrando o toString da classe AlunoPos junto com a classe mãe Aluno
        System.out.println(alunoP1);
        
        
    }

}

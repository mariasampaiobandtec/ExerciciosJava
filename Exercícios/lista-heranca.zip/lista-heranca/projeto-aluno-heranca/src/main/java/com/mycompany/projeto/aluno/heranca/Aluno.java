package com.mycompany.projeto.aluno.heranca;

/**
 *
 * @author DudaE
 */
public class Aluno {

    //Atributos
    protected Integer ra;
    protected String nome;
    protected Double notaContinuada;
    protected Double notaSemestral;

    //Construtor
    public Aluno(Integer ra, String nome, Double notaContinuada, Double notaSemestral) {
        this.ra = ra;
        this.nome = nome;
        this.notaContinuada = notaContinuada;
        this.notaSemestral = notaSemestral;
    }

    //Métodos
    public Double calculaMedia() {
       return (notaContinuada * 0.4) + (notaSemestral * 0.6);
    }

    //toString
    @Override
    public String toString() {
        return "\nRa: " + ra
                + "\nNome: " + nome
                + "\nNota Continuada: " + notaContinuada
                + "\nNota Semestral: " + notaSemestral
                + "\nMédia: " + calculaMedia();

    }

}

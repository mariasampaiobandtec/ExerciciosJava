package com.mycompany.projeto.aluno.heranca;

/**
 *
 * @author DudaE
 */
public class AlunoPos extends Aluno{
    
    //Atributos 
    private Double notaMonografia;
    
    //Construtor
    public AlunoPos(Integer ra, String nome, Double notaContinuada, Double notaSemestral, Double notaMonografia) {
        super(ra, nome, notaContinuada, notaSemestral);
        this.notaMonografia = notaMonografia;
    }
    
    //Métodos
    @Override
    public Double calculaMedia(){
        return (notaContinuada + notaSemestral + notaMonografia) / 3;
    }
    
    //toString
    @Override
    public String toString() {
        return "Aluno: " + super.toString() + 
               "\nNota Monografia:  " + notaMonografia;
    }
    
    
    
     
}

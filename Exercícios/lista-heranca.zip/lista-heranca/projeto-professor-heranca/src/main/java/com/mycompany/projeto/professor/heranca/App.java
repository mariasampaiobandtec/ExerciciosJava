package com.mycompany.projeto.professor.heranca;

/**
 *
 * @author DudaE
 */
public class App {
    
    public static void main(String[] args) {
        
        //Criando objeto da classe professor
        Professor prof1 = new Professor("Célia", 11, 40, 30.0);
        
        System.out.println(prof1);
        
        //Criando objeto da classe Coordenador, herdeira da classe Professor
        Coordenador coord1 = new Coordenador("Gerson", 10, 30, 40.0, 20, 30.0, "PI");
        
        System.out.println(coord1);
    }

}

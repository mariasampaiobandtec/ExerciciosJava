package com.mycompany.projeto.professor.heranca;

/**
 *
 * @author DudaE
 */
public class Coordenador extends Professor {

    //Atributos
    private Integer qtdHorasCoord;
    private Double valorHoraCoord;
    private String curso;

    //Construtor
    public Coordenador(String nome, Integer codigo, Integer horas, Double valorHora, Integer qtdHorasCoord, Double valorHoraCoord, String curso) {
        super(nome, codigo, horas, valorHora);
        this.qtdHorasCoord = qtdHorasCoord;
        this.valorHoraCoord = valorHoraCoord;
        this.curso = curso;
    }

    //Métodos
    @Override
    public Double calculaSalario() {
        return (getHoras() * getValorHora() * 4.5) + (qtdHorasCoord * valorHoraCoord * 4.5);
    }

    //toString
    @Override
    public String toString() {
        return "\nProfessor: " + super.toString()
                + "\nHoras de coordenação: " + qtdHorasCoord
                + "\nValor da hora de coordenação: " + valorHoraCoord
                + "\nCurso que coordena: " + curso;

    }

    public Integer getQtdHorasCoord() {
        return qtdHorasCoord;
    }

    public Double getValorHoraCoord() {
        return valorHoraCoord;
    }

    public String getCurso() {
        return curso;
    }
    
    

}

package com.mycompany.projeto.professor.heranca;

/**
 *
 * @author DudaE
 */
public class Professor {

    //Atributos
    private String nome;
    private Integer codigo;
    private Integer horas;
    private Double valorHora;

    //Construtores
    public Professor(String nome, Integer codigo, Integer horas, Double valorHora) {
        this.nome = nome;
        this.codigo = codigo;
        this.horas = horas;
        this.valorHora = valorHora;
    }

    //Métodos
    public Double calculaSalario() {
        return (horas * valorHora) * 4.5;
    }

    //toString
    @Override
    public String toString() {
        return "\nNome do Professor(a): " + nome
                + "\nCódigo: " + codigo
                + "\nHoras por semana: " + horas
                + "\nValor ganho por hora: " + valorHora
                + "\nSalário: " + calculaSalario();
    }

    //Getters e Setters
    public String getNome() {
        return nome;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public Integer getHoras() {
        return horas;
    }

    public Double getValorHora() {
        return valorHora;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public void setHoras(Integer horas) {
        this.horas = horas;
    }

    public void setValorHora(Double valorHora) {
        this.valorHora = valorHora;
    }

}

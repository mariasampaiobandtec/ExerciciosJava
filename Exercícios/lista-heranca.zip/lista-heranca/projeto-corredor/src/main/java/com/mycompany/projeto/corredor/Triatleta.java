package com.mycompany.projeto.corredor;

public class Triatleta extends Corredor{

    public Triatleta(String tipoFisico, String performance, Double tempoMedio) {
        super(tipoFisico, performance, tempoMedio);
    }
    
    

}

package com.mycompany.projeto.corredor;

public class Corredor {

    //Atributos
    protected String tipoFisico;
    protected String performance;
    protected Double tempoMedio;

    //Construtor
    public Corredor(String tipoFisico, String performance, Double tempoMedio) {
        this.tipoFisico = tipoFisico;
        this.performance = performance;
        this.tempoMedio = tempoMedio;
    }

    //Getter
    public String getTipoFisico() {
        return tipoFisico;
    }

    public String getPerformance() {
        return performance;
    }

    public Double getTempoMedio() {
        return tempoMedio;
    }

}

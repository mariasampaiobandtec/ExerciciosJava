package com.mycompany.projeto.corredor;

public class Maratonista extends Corredor{

    public Maratonista(String tipoFisico, String performance, Double tempoMedio) {
        super(tipoFisico, performance, tempoMedio);
    }
    
    

}

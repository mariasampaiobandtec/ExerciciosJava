package com.mycompany.projeto.corredor;

public class Velocista extends Corredor{

    public Velocista(String tipoFisico, String performance, Double tempoMedio) {
        super(tipoFisico, performance, tempoMedio);
    }
    
    

}

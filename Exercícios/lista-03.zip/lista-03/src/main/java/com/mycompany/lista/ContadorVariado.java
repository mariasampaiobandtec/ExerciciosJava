/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class ContadorVariado {
    
    public static void main(String[] args) {
        
        for (Double i = 0.0; i < 5; i += 0.15) {
            System.out.println(String.format("%.2f", i));
        }
    }
    
}

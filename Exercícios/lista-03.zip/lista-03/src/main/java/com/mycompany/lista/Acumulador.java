/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Acumulador {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        Integer valorDigitado, total = 0;

        do {
            System.out.println("Digite um número");

            valorDigitado = leitor.nextInt();

            total += valorDigitado;

        } while (!(valorDigitado.equals(0)));

        System.out.println(String.format("Total acumulado: %d", total));
    }
}

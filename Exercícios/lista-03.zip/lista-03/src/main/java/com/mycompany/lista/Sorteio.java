/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Sorteio {

    public static void main(String[] args) {

        Random gerar = new Random();
        Scanner leitor = new Scanner(System.in);

        System.out.println("Informe um número de 1 a 100");
        Integer numero = leitor.nextInt();
        Integer numeroGerado;
        Integer rodada = 0, pares = 0, impares = 0;
        Boolean encontrou = false;

        for (Integer i = 1; i <= 200; i++) {
            numeroGerado = gerar.nextInt(100) + 1;

            if (i % 2 == 0) {
                pares++;
            } else {
                impares++;
            }

            if (numeroGerado.equals(numero)) {
                rodada = i;
                encontrou = true;
                break;

            }
        }

        System.out.println(String.format("O número foi encontrado? %s \npares: %d \nimpares: %d \n"
                + "rodada %d", encontrou, pares, impares, rodada));

    }
}

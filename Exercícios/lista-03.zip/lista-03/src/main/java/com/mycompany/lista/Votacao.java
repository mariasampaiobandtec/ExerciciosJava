/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Votacao {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        Integer mussarela = 0;
        Integer calabresa = 0;
        Integer quatroQueijos = 0;
        Integer voto;

        System.out.println("Vote no seu sabor de pizza favorito\n"
                + "\n\t5\t|\tMussarela\t"
                + "\n\t25\t|\tCalabresa\t"
                + "\n\t50\t|\tQuatro Queijos\t");

        for (Integer i = 1; i <= 10; i++) {

            System.out.println(String.format("Digite %d° voto:", i));
            voto = leitor.nextInt();

            switch (voto) {
                case 5:
                    mussarela++;
                    break;
                case 25:
                    calabresa++;
                    break;
                case 50:
                    quatroQueijos++;
                    break;
                default:
                    System.out.println("Voto inválido!");
                    i--;
            }
        }

        System.out.println("Resultado da votação:\n");
        System.out.println(String.format("Mussarela: %d\nCalabresa: %d\nQuatro Queijos; %d\n", mussarela, calabresa, quatroQueijos));

        if (mussarela > calabresa && mussarela > quatroQueijos) {
            System.out.println("Mussarela é o sabor preferido dos alunos!");
        } else if (calabresa > mussarela && calabresa > quatroQueijos) {
            System.out.println("Calabresa é o sabor preferido dos alunos!");
        } else if (quatroQueijos > mussarela && quatroQueijos > calabresa) {
            System.out.println("Quatro Queijos é o sabor preferido dos alunos!");
        } else {
            System.out.println("Vish, empate! Deverá ser realizado outra votação.");
        }

    }

}

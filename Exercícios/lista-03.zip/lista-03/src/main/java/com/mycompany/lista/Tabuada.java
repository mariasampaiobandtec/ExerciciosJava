/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Tabuada {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
        
        System.out.println("Informe um número:");
        Integer numero = leitor.nextInt();
        
        for (Integer i = 0; i <= 10; i++){
            System.out.println(String.format("%d X %d = %d", numero , i , numero * i));
        }
    }
    
}

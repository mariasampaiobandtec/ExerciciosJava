/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class NúmerosImpares {

    public static void main(String[] args) {

        for (Integer i = 0; i < 90; i++) {
            
            if (!(i % 2 == 0)) {
                System.out.println(String.format("%d", i));
            }
        }
    }
}

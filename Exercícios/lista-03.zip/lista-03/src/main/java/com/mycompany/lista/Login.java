/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Login {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        String usuario = "admin";
        String senha = "#Bandtec";

        System.out.println("Usuário:");
        String usuarioDigitado = leitor.nextLine();

        System.out.println("Senha:");
        String senhaDigitada = leitor.nextLine();

        while (!(usuario.equals(usuarioDigitado)) || !(senha.equals(senhaDigitada))) {
            System.out.println("Usuário e/ou senha incorretos.");
            System.out.println("Tente novamente!");

            System.out.println("Usuário:");
            usuarioDigitado = leitor.nextLine();

            System.out.println("Senha:");
            senhaDigitada = leitor.nextLine();
        }

        System.out.println("Login realizado com sucesso!");
    }

}

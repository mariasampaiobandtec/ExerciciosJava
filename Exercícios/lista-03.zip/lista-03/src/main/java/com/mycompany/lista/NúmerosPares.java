/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author DudaE
 */
public class NúmerosPares {

    public static void main(String[] args) {

        for (Integer i = 2; i <= 40; i++){
            
            if (i % 2 == 0){
                System.out.println(i);
            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maria.ac1;

import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class Economia {
    
    public static void main(String[] args) {
        
        String nome;
        Double dia1, dia2, dia3, dia4, dia5, dia6, dia7;
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite o seu nome: ");
        nome = leitor.nextLine();
        
         System.out.println("Valor depositado no 1° dia");
         dia1 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 2° dia");
         dia2 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 3° dia");
         dia3 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 4° dia");
         dia4 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 5° dia");
         dia5 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 6° dia");
         dia6 = leitor.nextDouble();
         
         System.out.println("Valor depositado no 7° dia");
         dia7 = leitor.nextDouble();
         

         
         if (!(dia1 == 0.01 || dia1 == 0.05 || dia1 == 0.10 || dia1 == 0.25 || dia1 == 0.50 || dia1 == 1.00 )) {
          
          Double soma1 = dia2+dia3+dia4+dia5+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma1));
           
        } else if (!(dia2 == 0.01 || dia2 == 0.05 || dia2 == 0.10 || dia2 == 0.25 || dia2 == 0.50 || dia2 == 1.00 )) {
          
          Double soma2 = dia1+dia3+dia4+dia5+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma2));
           
        } else if (!(dia3 == 0.01 || dia3 == 0.05 || dia3 == 0.10 || dia3 == 0.25 || dia3 == 0.50 || dia3 == 1.00 )) {
          
          Double soma3 = dia1+dia2+dia4+dia5+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma3));
           
        } else if (!(dia4 == 0.01 || dia4 == 0.05 || dia4 == 0.10 || dia4 == 0.25 || dia4 == 0.50 || dia4 == 1.00 )) {
          
          Double soma4 = dia1+dia2+dia3+dia5+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma4));
    
        } else if (!(dia5 == 0.01 || dia5 == 0.05 || dia5 == 0.10 || dia5 == 0.25 || dia5 == 0.50 || dia5 == 1.00 )) {
          
          Double soma5 = dia1+dia2+dia3+dia4+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma5));
    
        } else if (!(dia5 == 0.01 || dia5 == 0.05 || dia5 == 0.10 || dia5 == 0.25 || dia5 == 0.50 || dia5 == 1.00 )) {
          
          Double soma5 = dia1+dia2+dia3+dia4+dia6+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma5));
    
        } else if (!(dia6 == 0.01 || dia6 == 0.05 || dia6 == 0.10 || dia6 == 0.25 || dia6 == 0.50 || dia6 == 1.00 )) {
          
          Double soma6 = dia1+dia2+dia3+dia4+dia5+dia7;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma6));
    
        } else if (!(dia7 == 0.01 || dia7 == 0.05 || dia7 == 0.10 || dia7 == 0.25 || dia7 == 0.50 || dia7 == 1.00 )) {
          
          Double soma7 = dia1+dia2+dia3+dia4+dia5+dia6;
   
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma7));
    
        } else {
           
            Double soma = dia1+dia2+dia3+dia4+dia5+dia6+dia7;
        
        System.out.print("Ao final de 7 dias, " +nome);
        System.out.print(String.format(" guardou %.2f", soma)); 
        }
       
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maria.ac1;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class EconomiaCorrecao {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        Double valor = 0.0;
        Double soma = 0.0;

        System.out.println("Digite o seu nome: ");
        String nome = leitor.nextLine();

        for (int cont = 1; cont <= 7; cont++) {
            System.out.println("Valor depositado no " + cont + "° dia");
            valor = leitor.nextDouble();

            if (valor == 0.01 || valor == 0.05 || valor == 0.10 || valor == 0.25 || valor == 0.50 || valor == 1.0) {
                soma += valor;

            } else {
                valor += 0;
            }

        }
        
        System.out.println(String.format("Ao final de 7 dias, %s guardou R$%.2f", nome, soma));
    }

}

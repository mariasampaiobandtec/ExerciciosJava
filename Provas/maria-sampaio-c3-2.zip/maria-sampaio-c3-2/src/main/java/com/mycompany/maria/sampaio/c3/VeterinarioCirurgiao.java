package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class VeterinarioCirurgiao extends Veterinario {

    //Atributos
    private Integer cigurgias;
    private Double valorCirurgia;

    //Construtor
    public VeterinarioCirurgiao(Integer codigo, String nome, Integer cigurgias, Double valorCirurgia) {
        super(codigo, nome);
        this.cigurgias = cigurgias;
        this.valorCirurgia = valorCirurgia;
    }

    //Métodos
    @Override
    public Double calculaSalario() {
        return cigurgias * valorCirurgia;
    }

    //Getters
    public Integer getCigurgias() {
        return cigurgias;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    //toString
    @Override
    public String toString() {
        return "\nVeterinário(a) Cirurgião"
                + super.toString()
                + "\nCigurgias: " + cigurgias
                + "\nValor Cirurgia: " + valorCirurgia;
    }

}

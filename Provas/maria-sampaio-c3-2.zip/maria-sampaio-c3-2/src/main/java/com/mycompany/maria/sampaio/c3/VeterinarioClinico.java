package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class VeterinarioClinico extends Veterinario {

    //Atributos
    private Integer consultas;
    private Double valorConsulta;

    //Construtor
    public VeterinarioClinico(Integer codigo, String nome, Integer consultas, Double valorConsulta) {
        super(codigo, nome);
        this.consultas = consultas;
        this.valorConsulta = valorConsulta;
    }

    //Métodos
    @Override
    public Double calculaSalario() {
        return consultas * valorConsulta;
    }

    //Getters
    public Integer getConsultas() {
        return consultas;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }

    //toString
    @Override
    public String toString() {
        return "\nVeterinário(a) Clinico"
                + super.toString()
                + "\nConsultas: " + consultas
                + "\nValor Consulta: " + valorConsulta;
    }

}

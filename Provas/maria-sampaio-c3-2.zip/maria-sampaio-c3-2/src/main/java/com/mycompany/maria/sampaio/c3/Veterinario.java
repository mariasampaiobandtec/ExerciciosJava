package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public abstract class Veterinario {

    //Atributos
    private Integer codigo;
    private String nome;

    //Construtor
    public Veterinario(Integer codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    //Métodos
    public abstract Double calculaSalario();

    //Getters
    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    //toString
    @Override
    public String toString() {
        return "\nCódigo: " + codigo
                + "\nNome: " + nome
                + "\nSalário: " + calculaSalario();
    }

}

package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class App {

    public static void main(String[] args) {

        //Criando objetos da classe VeterinarioClinico
        VeterinarioClinico vc1 = new VeterinarioClinico(1020, "Maria", 40, 400.00);
        VeterinarioClinico vc2 = new VeterinarioClinico(2030, "Pedro", 40, 500.00);

        //Criando objetos da classe VeterinarioCirurgiao
        VeterinarioCirurgiao vci1 = new VeterinarioCirurgiao(4050, "Diego", 20, 1000.00);
        VeterinarioCirurgiao vci2 = new VeterinarioCirurgiao(5060, "Célia", 20, 2000.00);
        
        //Criando objeto da ClinicaVeterinaria
        ClinicaVeterinaria clinica = new ClinicaVeterinaria("Clínica Tech");
        
        System.out.println(clinica);

        //Cadastrando veterinários
        clinica.contrataVeterinario(vc1);
        clinica.contrataVeterinario(vc2);
        clinica.contrataVeterinario(vci1);
        clinica.contrataVeterinario(vci2);

        //Exibindo apenas veterinários clínicos
        clinica.exibeClinicos();

        //Exibindo apenas veterinários cirurgiões
        clinica.exibeCirurgioes();

        //Exibindo Folha de Pagamento
        clinica.exibeFolhaDePagamento();
        

    }

}

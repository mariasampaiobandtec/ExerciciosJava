package com.mycompany.maria.sampaio.c3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DudaE
 */
public class ClinicaVeterinaria {

    //Atributos
    private String nome;
    private List<Veterinario> veterinarios;

    //Construtor
    public ClinicaVeterinaria(String nome) {
        this.nome = nome;
        this.veterinarios = new ArrayList<>();
    }

    //Métodos
    public void contrataVeterinario(Veterinario veterinario) {
        veterinarios.add(veterinario);
    }

    //Exibe somente os veterinários clínicos
    public void exibeClinicos() {
        if (!veterinarios.isEmpty()) {
            for (Veterinario veterinario : veterinarios) {
                if (veterinario instanceof VeterinarioClinico) {
                    System.out.println(veterinario);
                }
            }
        } else {
            System.out.println("Não existe Veterinários Clínicos cadastrados");
        }
    }

    //Exibe somente os veterinários cirurgiões
    public void exibeCirurgioes() {
        if (!veterinarios.isEmpty()) {
            for (Veterinario veterinario : veterinarios) {
                if (veterinario instanceof VeterinarioCirurgiao) {
                    System.out.println(veterinario);
                }
            }
        } else {
            System.out.println("Não existe Veterinários Cirurgiões cadastrados");
        }
    }

    //Exibe nome e salário dos veterinários cadastrados e o valor total dos salários pagos
    public void exibeFolhaDePagamento() {
        Double totalSalario = 0.0;

        if (!veterinarios.isEmpty()) {
            for (Veterinario veterinario : veterinarios) {
                System.out.println(String.format("\nNome veterinário(a): %s \nSalário: %.2f", veterinario.getNome(), veterinario.calculaSalario()));
                totalSalario += veterinario.calculaSalario();
            }
        } else {
            System.out.println("Sem veterinários.");
        }

        System.out.println(String.format("Total Salário: %.2f", totalSalario));
    }

    //Getters
    public String getNome() {
        return nome;
    }

    public List<Veterinario> getVeterinarios() {
        return veterinarios;
    }

    //toString
    @Override
    public String toString() {
        return "\nClínica Veterinaria" 
                + "\nNome: " + nome 
                + "\nVeterinários: " + veterinarios;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.prova.alternativa;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Aviao {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o seu nome: ");
        String nome = leitor.nextLine();

        Integer voo = 0;
        Double totalVoo = 0.0;

        while (!(voo < 0)) {
            System.out.println("\nDe quantas horas foi seu último vôo?");
            Integer horasVoo = leitor.nextInt();

            if (horasVoo == 0 || horasVoo > 6) {
                System.out.println("Quantidade inválida! Não será registrada!");
            } else if (horasVoo > 0 && horasVoo <= 6) {
                voo++;
                totalVoo += horasVoo;
                System.out.println(String.format("%s agora tem um total de %.2f horas de vôo.", nome, totalVoo));
            } else {
                System.out.println(String.format("%s se aposentou após fazer %d vôos acumulando %.2f horas!", nome, voo, totalVoo));
                break;
            }

        }
    }

}

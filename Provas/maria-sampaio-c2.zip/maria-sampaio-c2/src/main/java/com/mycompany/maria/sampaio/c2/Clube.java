/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maria.sampaio.c2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DudaE
 */
public class Clube {

    //Atributos
    private String nome;
    private Double caixa;
    private List<Jogador> listaJogador;

    //Construtores
    public Clube(String nome, Double caixa) {
        this.nome = nome;
        this.caixa = caixa;
        this.listaJogador = new ArrayList<>();
    }

    //Métodos
    public void contratarJogador(Jogador jogador) {
        Jogador jogadores = new Jogador(nome, Integer.SIZE, Integer.SIZE, caixa); //Necessário excluir essa linha

        if (jogador.getValorDoPasse() < caixa) { 
            listaJogador.add(jogadores); //Trocar 'jogadores' para 'jogador'
            caixa -= jogador.getValorDoPasse();
        } else {
            System.out.println(String.format("\nFundos insuficientes para contratar o jogador %s", jogador.getNome()));
        }
    }

    public void exibeJogadores() {
        if (listaJogador.isEmpty()) {
            System.out.println("\nVocê não contratou nenhum jogador ainda");
        } else {
            System.out.println("\n----Informações sobre o jogador----\n");

            for (Jogador jogadores : listaJogador) {
                System.out.println(String.format("Idade: %d anos", jogadores.getIdade()));
                System.out.println(String.format("Posicão: %d", jogadores.getPosicao()));
                System.out.println(String.format("Valor do Passe: %.2f", jogadores.getValorDoPasse()));

            }
        }
    }

    public void exibeCaixa() {

        System.out.println(String.format("\nSaldo Disponível: %.2f", caixa));
    }

    //Getters
    public String getNome() {
        return nome;
    }

    public Double getCaixa() {
        return caixa;
    }

    public List<Jogador> getListaJogador() {
        return listaJogador;
    }

    //toString
    @Override
    public String toString() {
        return "Clube{" + "nome=" + nome + ", caixa=" + caixa + ", listaJogador=" + listaJogador + '}';
    }

}

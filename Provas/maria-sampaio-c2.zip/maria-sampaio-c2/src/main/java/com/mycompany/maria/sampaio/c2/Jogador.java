/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maria.sampaio.c2;

/**
 *
 * @author DudaE
 */
public class Jogador {

    //Atributos
    private String nome;
    private Integer idade;
    private Integer posicao;
    private Double valorDoPasse;

    //Construtores
    public Jogador(String nome, Integer idade, Integer posicao, Double valorDoPasse) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
        this.valorDoPasse = valorDoPasse;
    }

    //Métodos
    public void exibeDados() {
        System.out.println("------------------------------------------------------");
        System.out.println(String.format("Nome do jogador: %s", nome));
        System.out.println(String.format("Idade: %d anos", idade));
        System.out.println(String.format("Posição: %d", posicao));
        System.out.println(String.format("Valor do Passe: %.2f reais", valorDoPasse));
    }

    //Getter
    public String getNome() {
        return nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public Integer getPosicao() {
        return posicao;
    }

    public Double getValorDoPasse() {
        return valorDoPasse;
    }

    //toString
    @Override
    public String toString() {
        return "Jogador{" + "nome=" + nome + ", idade=" + idade + ", posicao=" + posicao + ", valorDoPasse=" + valorDoPasse + '}';
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maria.sampaio.c2;

/**
 *
 * @author DudaE
 */
public class ProgramaClube {
    
    public static void main(String[] args) {
        
        Jogador jogador1 = new Jogador("Paulo Sérgio", 25, 10, 20000.00);
        jogador1.exibeDados();
        
        Clube clube1 = new Clube("Palmeiras", 10000.00);
        
        clube1.contratarJogador(jogador1);
        
        clube1.exibeJogadores();
        
        clube1.exibeCaixa();
        
        Jogador jogador2 = new Jogador("Pedro Silva", 21, 11, 2000.00);
        jogador2.exibeDados();
       
        clube1.contratarJogador(jogador2);
       
        clube1.exibeJogadores();
       
        clube1.exibeCaixa();
        
        
    }
}

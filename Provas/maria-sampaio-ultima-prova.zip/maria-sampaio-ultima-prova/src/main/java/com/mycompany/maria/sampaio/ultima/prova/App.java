package com.mycompany.maria.sampaio.ultima.prova;

/**
 *
 * @author DudaE
 */
public class App {

    public static void main(String[] args) {

        Heroi hero1 = new Heroi("Feiticeira escarlate", "Maria Sampaio");
        Heroi hero2 = new Heroi("Visão", "Pedro Mendes");

        hero1.adicionaPoder("Manipulação da mente", 8);
        hero2.adicionaPoder("Manipular densidade", 8);

        Vilao vilao1 = new Vilao("Thanos", "Fernando");
        Vilao vilao2 = new Vilao("Nebulosa", "Juliana");

        vilao1.adicionaPoder("Manopla do Infinito", 7);
        vilao2.adicionaPoder("Artes marciais", 6);

        //toString Heróis
        System.out.println(hero1);
        System.out.println(hero2);

        //toString Vilões
        System.out.println(vilao1);
        System.out.println(vilao2);

        System.out.println(String.format("\nE a batalha começa entre %s e %s!", hero2.codinome, vilao1.codinome));
        Confronto.lutar(hero2, vilao1);

        System.out.println(String.format("\nE a batalha começa entre %s e %s!", hero1.codinome, vilao2.codinome));
        Confronto.lutar(hero1, vilao2);
    }

}

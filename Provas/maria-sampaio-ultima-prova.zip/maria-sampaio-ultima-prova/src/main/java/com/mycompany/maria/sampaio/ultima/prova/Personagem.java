package com.mycompany.maria.sampaio.ultima.prova;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DudaE
 */
public abstract class Personagem {

    //Atributos
    protected String codinome;
    protected String nome;
    protected List<SuperPoder> poderes;

    //Construtor
    public Personagem(String codinome, String nome) {
        this.codinome = codinome;
        this.nome = nome;
        this.poderes = new ArrayList<>();
    }

    //Métodos
    public void adicionaPoder(String nome, Integer categoria) {
        SuperPoder poder = new SuperPoder(nome, categoria);
        poderes.add(poder);
    }

    public abstract Double getForcaTotal();

    //Getters
    public String getCodinome() {
        return codinome;
    }

    public String getNome() {
        return nome;
    }

    public List<SuperPoder> getPoderes() {
        return poderes;
    }

    //toString
    @Override
    public String toString() {
        return "\nNome: " + nome
                + "\nCodinome: " + codinome
                + poderes
                + "\nForça Total: " + getForcaTotal();
    }

}

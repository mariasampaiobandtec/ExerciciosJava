package com.mycompany.maria.sampaio.ultima.prova;

/**
 *
 * @author DudaE
 */
public class Heroi extends Personagem {

    //Construtor
    public Heroi(String codinome, String nome) {
        super(codinome, nome);
    }

    //Métodos 
    @Override
    public Double getForcaTotal() {
        Double totalHeroi = 0.0;

        if (!getPoderes().isEmpty()) {
            for (SuperPoder poder : poderes) {
                totalHeroi += poder.getCategoria();
            }
        } else {
            System.out.println("Não existe nenhum Super Poder existente :/ ");
        }
        return totalHeroi + (15 / 100);
    }

    //toString 
    @Override
    public String toString() {
        return "\nHeróis"
                + super.toString();

    }
}

package com.mycompany.maria.sampaio.ultima.prova;

/**
 *
 * @author DudaE
 */
public class Confronto {

    //Métodos
    public static void lutar(Heroi heroi, Vilao vilao) {
        if (heroi.getForcaTotal() < vilao.getForcaTotal()) {
            System.out.println(String.format("\nE no final, o mal ganhou a Terra pelo(a) %s", vilao.getCodinome()));
        } else if (heroi.getForcaTotal() > vilao.getForcaTotal()) {
            System.out.println(String.format("\nO lado bom da força reina pelo(a) %s", heroi.getCodinome()));
        } else {
            System.out.println("\nNem o bem, nem o mal. Apenas aguardadando que vencerá a batalha!");
        }
    }

}

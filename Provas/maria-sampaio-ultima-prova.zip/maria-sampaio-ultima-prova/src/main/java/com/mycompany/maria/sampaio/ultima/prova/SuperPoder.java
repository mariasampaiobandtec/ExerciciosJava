package com.mycompany.maria.sampaio.ultima.prova;

/**
 *
 * @author DudaE
 */
public class SuperPoder {

    //Atributos
    private String nome;
    private Integer categoria;

    //Construtor
    public SuperPoder(String nome, Integer categoria) {
        this.nome = nome;
        this.categoria = categoria;
    }

    //Getters
    public String getNome() {
        return nome;
    }

    public Integer getCategoria() {
        return categoria;
    }

    //toString
    @Override
    public String toString() {
        return "\nSuper Poder: " + nome
                + "\nCategoria: " + categoria;
    }

}

package com.mycompany.maria.sampaio.ultima.prova;

/**
 *
 * @author DudaE
 */
public class Vilao extends Personagem {

    //Construtor
    public Vilao(String codinome, String nome) {
        super(codinome, nome);
    }

    //Métodos
    @Override
    public Double getForcaTotal() {
        Double totalVilao = 0.0;

        if (!getPoderes().isEmpty()) {
            for (SuperPoder poder : poderes) {
                totalVilao += poder.getCategoria();
            }
        } else {
            System.out.println("Não existe nenhum Super Poder existente :/ ");
        }

        return totalVilao;
    }

    //toString
    @Override
    public String toString() {
        return "\nVilões"
                + super.toString();

    }

}

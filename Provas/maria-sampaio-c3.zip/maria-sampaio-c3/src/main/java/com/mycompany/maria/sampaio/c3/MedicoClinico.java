package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class MedicoClinico {

    //Atributos
    protected Integer codigo;
    protected String nome;
    protected Integer qtdConsulta;
    protected Double valorConsulta;

    //Construtor
    public MedicoClinico(Integer codigo, String nome, Integer qtdConsulta, Double valorConsulta) {
        this.codigo = codigo;
        this.nome = nome;
        this.qtdConsulta = qtdConsulta;
        this.valorConsulta = valorConsulta;
    }

    //Métodos
    public Double calcularSalario() {
        return qtdConsulta * valorConsulta;
    }

    //Getter
    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public Integer getQtdConsulta() {
        return qtdConsulta;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }

    //toString
    @Override
    public String toString() {
        return "\nMedico Clinico "
                + "\nCódigo: " + codigo
                + "\nNome: " + nome
                + "\nConsultas realizadas: " + qtdConsulta
                + "\nValor da consulta: " + valorConsulta
                + "\nSalário: " + calcularSalario();
    }

}

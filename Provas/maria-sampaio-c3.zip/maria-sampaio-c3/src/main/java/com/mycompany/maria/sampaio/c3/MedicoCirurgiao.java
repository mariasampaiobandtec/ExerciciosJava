package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class MedicoCirurgiao extends MedicoClinico {

    //Atributos
    private Integer qtdCirurgia;
    private Double valorCirurgia;

    //Construtor
    public MedicoCirurgiao(Integer codigo, String nome, Integer qtdConsulta, Double valorConsulta, Integer qtdCirurgia, Double valorCirurgia) {
        super(codigo, nome, qtdConsulta, valorConsulta);
        this.qtdCirurgia = qtdCirurgia;
        this.valorCirurgia = valorCirurgia;
    }

    //Métodos
    @Override
    public Double calcularSalario() {
        return super.calcularSalario() + (qtdCirurgia * valorCirurgia);
    }

    //Getter
    public Integer getQtdCirurgia() {
        return qtdCirurgia;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    //toString - OBS: Era possível chamar o super.toString(), porém quis deixar arrumado.
    @Override
    public String toString() {
        return "\nMédico Cirurgião "
                + "\nCódigo: " + codigo
                + "\nNome: " + nome
                + "\nConsultas realizadas: " + qtdConsulta
                + "\nValor da consulta: " + valorConsulta
                + "\nQuantidade de Cirurgias: " + qtdCirurgia
                + "\nValor Cirurgia: " + valorCirurgia
                + "\nSalário: " + calcularSalario();
    }

}

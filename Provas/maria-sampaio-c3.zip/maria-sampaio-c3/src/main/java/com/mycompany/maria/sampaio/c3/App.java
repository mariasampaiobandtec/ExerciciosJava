package com.mycompany.maria.sampaio.c3;

/**
 *
 * @author DudaE
 */
public class App {

    public static void main(String[] args) {

        //Criando objetos da classe MedicoClinico
        MedicoClinico mcli1 = new MedicoClinico(100, "Diogo Tavares", 20, 100.00);
        MedicoClinico mcli2 = new MedicoClinico(105, "Ana Cruz", 30, 200.00);
        
        System.out.println(mcli1);
        System.out.println(mcli2);

        //Criando objetos da classe MedicoCirurgiao
        MedicoCirurgiao mcir1 = new MedicoCirurgiao(200, "Paula Santos", 15, 150.00, 20, 1000.00);
        MedicoCirurgiao mcir2 = new MedicoCirurgiao(201, "José Pedro", 20, 100.00, 20, 500.00);

        System.out.println(mcir1);
        System.out.println(mcir2);
    }

}

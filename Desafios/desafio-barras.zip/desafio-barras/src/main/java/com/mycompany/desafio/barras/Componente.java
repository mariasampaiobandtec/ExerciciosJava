/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.desafio.barras;

import java.util.Random;

/**
 *
 * @author DudaE
 */
public class Componente {
    
    Integer valor;
    String cor = "#000";
    String status = "";
    
    Random gerar = new Random(101);
    
    void atualizarDados() {
        valor = gerar.nextInt(101);
    }
    
    void atualizarStatus(){
        if (valor >= 0 && valor <=20){
            status = "Suave";
            cor = "#0e0872";
        } else if (valor > 20 && valor <= 70){
            status = "Atenção";
            cor = "#8B008B";
        } else 
            status = "Crítico";
            cor = "#FF0000";
    }
    
}

package com.mycompany.desafio.conta.corrente;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DudaE
 */
public class ContaCorrente {

    // Atributos
    private String titular;
    private Double saldo;
    private List<Historico> listaHistorico;

    // Construtores
    public ContaCorrente(String titular, Double saldo) {
        this.titular = titular;
        this.saldo = saldo;
        this.listaHistorico = new ArrayList<>();
    }

    // Métodos 
    public void depositar(Double valor, Integer dia, Integer mes, Integer ano) {

        Historico historicos = new Historico(valor, dia, mes, ano);
        historicos.setOperacao("Depósito");

        listaHistorico.add(historicos);

        saldo += valor;

    }

    public void sacar(Double valor, Integer dia, Integer mes, Integer ano) {

        Historico historicos = new Historico(valor, dia, mes, ano);
        historicos.setOperacao("Saque");

        listaHistorico.add(historicos);

        saldo -= valor;
    }

    public void exibirExtrato() {

        System.out.println(String.format("\nTitular: %s", titular));

        for (Historico extrato : listaHistorico) {
            System.out.println(String.format("\nValor da transação: %.2f", extrato.getValor()));
            System.out.println(String.format("Data da transação: %d/%d/%d", extrato.getDia(), extrato.getMes(), extrato.getAno()));
            System.out.println(String.format("Tipo da operação: %s", extrato.getOperacao()));
        }

        System.out.println(String.format("\nSaldo: %.2f", saldo));

        System.out.println("\n---------------------------------------------------------------\n");

    }

    // Getter
    public String getTitular() {
        return titular;
    }

    public Double getSaldo() {
        return saldo;
    }

    public List<Historico> getListaHistorico() {
        return listaHistorico;
    }

    @Override
    public String toString() {
        return "ContaCorrente{" + "titular=" + titular + ", saldo=" + saldo + ", listaHistorico=" + listaHistorico + '}';
    }

}

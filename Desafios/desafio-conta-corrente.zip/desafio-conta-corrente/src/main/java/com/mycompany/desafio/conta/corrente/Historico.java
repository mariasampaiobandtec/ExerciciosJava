package com.mycompany.desafio.conta.corrente;

/**
 *
 * @author DudaE
 */
public class Historico {

    // Atributos
    private Double valor;
    private Integer dia;
    private Integer mes;
    private Integer ano;
    private String operacao;

    // Construtores
    public Historico(Double valor, Integer dia, Integer mes, Integer ano) {
        this.valor = valor;
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;

    }

    // Getter e Setter
    public Double getValor() {
        return valor;
    }

    public Integer getDia() {
        return dia;
    }

    public Integer getMes() {
        return mes;
    }

    public Integer getAno() {
        return ano;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    @Override
    public String toString() {
        return "Historico{" + "valor=" + valor + ", dia=" + dia + ", mes=" + mes + ", ano=" + ano + ", operacao=" + operacao + '}';
    }

}

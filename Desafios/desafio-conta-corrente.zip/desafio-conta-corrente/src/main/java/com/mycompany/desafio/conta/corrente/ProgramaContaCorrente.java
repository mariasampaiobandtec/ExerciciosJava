package com.mycompany.desafio.conta.corrente;

/**
 *
 * @author DudaE
 */
public class ProgramaContaCorrente {

    public static void main(String[] args) {

        ContaCorrente titular1 = new ContaCorrente("Maria Sampaio", 1800.00);

        titular1.depositar(800.00, 03, 04, 2020);
        titular1.sacar(400.00, 19, 04, 2020);

        titular1.exibirExtrato();

        ContaCorrente titular2 = new ContaCorrente("Ficuciello", 1800.00);

        titular2.depositar(200.00, 21, 04, 2020);

        titular2.exibirExtrato();
    }

}

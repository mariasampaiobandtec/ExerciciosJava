/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Calculadora {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite um número");
        Double num1 = leitor.nextDouble();
        
        System.out.println("Digite um número");
        Double num2 = leitor.nextDouble();
        
        System.out.println("Resultado da soma: " + (num1 + num2));
        System.out.println("Resultado da subtração: " + (num1 - num2));
        System.out.println("Resultado da multiplicação: " + (num1 * num2));
        System.out.println("Resultado da divisão: " + (num1 / num2));
    }
    
}

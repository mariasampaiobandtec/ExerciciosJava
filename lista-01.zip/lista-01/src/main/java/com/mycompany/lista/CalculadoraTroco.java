/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class CalculadoraTroco {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
        
        System.out.println("Qual o valor unitário do produto?");
        Double valorProduto = leitor.nextDouble();
        
        System.out.println("Informe a quantidade vendida");
        Integer qtdVendida = leitor.nextInt();
        
        System.out.println("Informe o valor pago pelo o cliente");
        Double vlrPago = leitor.nextDouble();
        
        System.out.println("O troco será de R$" + (vlrPago - (valorProduto * qtdVendida)));
      
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 *
 * @author DudaE
 */
public class Elevador {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner (System.in);
       
        System.out.println("Qual é o limite de peso do elevador?");
        Integer pesoLimite = leitor.nextInt();
        
        System.out.println("Qual o limite de pessoas para o elevador?");
        Integer pessoasLimite = leitor.nextInt();
        
        System.out.println("Qual o peso da 1° pessoa que entrou no elevador?");
        Double pesoTotal = leitor.nextDouble();
        
        System.out.println("Qual o peso da 2° pessoa que entrou no elevador?");
        pesoTotal += leitor.nextDouble();
        
        System.out.println("Qual o peso da 3° pessoa que entrou no elevador?");
        pesoTotal += leitor.nextDouble();
        
        System.out.println("Entraram 3 pessoas no elevador, no qual cabem " +pessoasLimite+ " pessoas.");
        System.out.println("O peso total no elevador é de " +pesoTotal+ ", sendo que ele suporta " +pesoLimite);
        
        
        
      
    }
}
